package com.example.change_helper

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
